class teststring{
	public static void main(String[] args) {
		String s1="Hello";
		String s2="How@are@you";
		System.out.println("s1:"+s1);
		System.out.println("s2:"+s2);
		System.out.println("length of s1:"+s1.length());
		System.out.println("length of s2:"+s2.length());
		System.out.println("lndex of e:"+s1.indexOf('e'));
		System.out.println("charAt(2):"+s1.charAt(2));
		System.out.println("To lower:"+s1.toLowerCase());
		System.out.println("split:");
		String[] s=s2.split("@");
		for (String a:s) {
			System.out.println(a);
		}
		System.out.println("substring:"+s2.substring(2,7));
		System.out.println("Replace l to a:"+s1.replace('l','a'));
		
	}
}