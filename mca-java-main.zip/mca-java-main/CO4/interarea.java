package Graphic;
interface interarea{
	 public void area();
}