package domath;
public interface docal{
	 public void calculate();
}