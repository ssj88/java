package Graphic;
public interface interarea{
	 public void area();
}